"""Simple project launcher."""

from src.main import main

if __name__ == "__main__":
    raise SystemExit(main())
