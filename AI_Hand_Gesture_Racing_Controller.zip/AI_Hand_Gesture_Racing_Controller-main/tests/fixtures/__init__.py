"""Reusable deterministic fixtures."""
